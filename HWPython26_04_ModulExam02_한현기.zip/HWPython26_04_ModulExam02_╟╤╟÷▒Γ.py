from modl_2 import *

print(sum(3,4))
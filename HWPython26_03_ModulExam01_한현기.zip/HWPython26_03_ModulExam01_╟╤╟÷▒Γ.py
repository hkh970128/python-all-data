import mod_1


print(mod_1.sum(3,4))

from mod_1 import *

print(sum(3,4))
print(safe_sum(3,4))
x = 5 
y ="han"
print(type(x))
print(type(y))
 



x ,y ,z  = "orange" , "Banana" , "cherry" 
print(x)
print(y)
print(z)


x = y = z ="orange" 
print(x)
print(y)
print(z)

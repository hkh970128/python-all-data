import csv

file = open('./../_dataSet01\emp2.csv','r')

emp_csv = csv.reader(file)
emp = list(emp_csv)



name = input("검색할 사원명을 입력하세요 :")

for i in range(len(emp)) :
	if name == emp[i][1] :
		print(emp[i][1],"의 급여는",emp[i][5],"입니다")




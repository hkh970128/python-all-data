import modl_3 



a = modl_3.Math()
print(a.solv(2))
print(modl_3.sum(modl_3.PI,4.4))

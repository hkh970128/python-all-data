import myModule3.mod3

print(myModule3.mod3.sum(1,2))